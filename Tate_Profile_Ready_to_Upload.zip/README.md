<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/hero-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/hero-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/hero.svg" />
  <img src="assets/light/hero.svg" width="1000" alt="Tate Socha. I build products that keep the pieces together." />
</picture>

[Explore my repositories](https://github.com/tatesocha?tab=repositories)

## Selected work

Illustrative product workflows. These previews do not assert a release status or show live product execution.

<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/volley-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/volley-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/volley.svg" />
  <img src="assets/light/volley.svg" width="1000" alt="Volley: Turn what you own and what inspires you into complete outfits. Illustrative workflow." />
</picture>

Turn what you own and what inspires you into complete outfits.

<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/onbrand-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/onbrand-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/onbrand.svg" />
  <img src="assets/light/onbrand.svg" width="1000" alt="Onbrand: Turn brand context into cohesive, reviewable content packages. Illustrative workflow." />
</picture>

Turn brand context into cohesive, reviewable content packages.

<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/desk-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/desk-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/desk.svg" />
  <img src="assets/light/desk.svg" width="1000" alt="The Desk: Launch through coordinated workstreams. Keep the business aligned as it changes. Illustrative workflow." />
</picture>

Launch through coordinated workstreams. Keep the business aligned as it changes.

<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/portwell-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/portwell-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/portwell.svg" />
  <img src="assets/light/portwell.svg" width="1000" alt="Portwell: Prepare for software discontinuations and migrations with evidence-backed, reviewable plans. Illustrative workflow." />
</picture>

Prepare for software discontinuations and migrations with evidence-backed, reviewable plans.

<picture>
  <source media="(max-width: 640px) and (prefers-color-scheme: dark)" srcset="assets/dark/carryplane-mobile.svg" />
  <source media="(max-width: 640px)" srcset="assets/light/carryplane-mobile.svg" />
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/carryplane.svg" />
  <img src="assets/light/carryplane.svg" width="1000" alt="Powered by Carryplane. Internal context and continuity layer. Architecture direction, not verified integration." />
</picture>

Carryplane is our internal context and continuity layer, designed to connect work to its evidence, decisions, and dependencies. The diagram presents architecture direction, not a claim of verified integration across the products.

<details>
<summary>GitHub activity</summary>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dark/activity.svg" />
  <img src="assets/light/activity.svg" width="1000" alt="Public GitHub activity. Unavailable and stale observations are labeled." />
</picture>

</details>
