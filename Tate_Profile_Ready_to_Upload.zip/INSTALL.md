# Fast installation

1. Unzip this package on your computer.
2. Open github.com/tatesocha/tatesocha while signed in.
3. Add file > Upload files.
4. Upload README.md and the assets folder to the repository ROOT.
5. Review and commit. Open github.com/tatesocha to view your profile.

Do not upload the ZIP itself or an enclosing folder. Keep the asset folders intact.
No secret, token, font installation, build step or external stats service is required
for the profile to display. Light/dark and narrow-screen variants are included.
The optional activity panel correctly starts without live data.

Use the separate full studio package for regeneration, preview controls and optional
scheduled activity refresh. No files have been published to your account for you.
Project scenes are illustrations; Carryplane is marked as architecture direction.
